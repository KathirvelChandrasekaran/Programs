package com.main;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestSum {

	@Test
	public void testSum() {
		Main main = new Main();
		int a=main.mark1();
		int b=main.mark2();
		int c=main.mark3();
		int d=main.mark4();
		int e=main.mark5();
		int sum=a+b+c+d+e;
		System.out.println("Total mark is "+sum);
		assertTrue(sum>=250);
	}

}
