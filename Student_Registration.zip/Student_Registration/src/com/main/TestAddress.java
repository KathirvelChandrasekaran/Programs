package com.main;

import static org.junit.Assert.*;

import java.util.Scanner;

import org.junit.Test;

public class TestAddress {

		Scanner in=new Scanner(System.in);
			
			@Test
			public void testName() {
				System.out.println("Enter the address");
				String address =in.nextLine();
				Main main=new Main();
			      assertEquals(address,main.address());
			      assertNotNull(address,main.address());
			   }
}