package com.main;

import java.util.*;

public class Main {
	Scanner in = new Scanner(System.in);
	private String name = "xyz";
	private String age = "18";
	private String address = "abc";

	 int mark1;
	public String name() {
		if (name.isEmpty())
			return null;
		return name;
	}

	public String age() {
		return age;
	}

	public String gender() {
		System.out.println("Enter the Gender ");
		String g=in.nextLine();
		if((g.equals("male")||(g.equals("female"))))
		return g;
		return g;
	}
	public String address() {
		return address;
	}

	public int mark1() {
		System.out.println("Enter the mark 1");
		int mark1 = in.nextInt();
		return mark1;
	}

	public int mark2() {
		System.out.println("Enter the mark 2");
		int mark2 = in.nextInt();
		return mark2;
	}

	public int mark3() {
		System.out.println("Enter the mark 3");
		int mark3 = in.nextInt();
		return mark3;
	}

	public int mark4() {
		System.out.println("Enter the mark 4");
		int mark4 = in.nextInt();
		return mark4;
	}

	public int mark5() {
		System.out.println("Enter the mark 5");
		int mark5 = in.nextInt();
		return mark5;
	}
	
//	public int sum() {
//		re
//	}
}