package com.main;

import static org.junit.Assert.*;

import java.util.Scanner;

import org.junit.Test;

public class TestMark3 {

	Scanner in = new Scanner(System.in);

	@Test
	public void testMark3() {
		Main main = new Main();
		int a=main.mark3();
		assertTrue((a >= 50) && (a <= 100));
//		assertNotNull(main.mark1());
	}
}
