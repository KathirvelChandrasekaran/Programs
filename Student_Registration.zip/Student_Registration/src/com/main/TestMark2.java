package com.main;

import static org.junit.Assert.*;

import java.util.Scanner;

import org.junit.Test;

public class TestMark2 {

	@Test
	public void testMark2() {
		Main main = new Main();
		int a=main.mark2();
		assertTrue((a >= 50) && (a <= 100));
//		assertNotNull(main.mark1());
	}

}
