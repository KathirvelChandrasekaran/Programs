package com.main;

import static org.junit.Assert.*;

import java.util.Scanner;

import org.junit.Test;

public class TestMark1 {
	Scanner in = new Scanner(System.in);

	@Test
	public void testMark1() {
		Main main = new Main();
		int a=main.mark1();
		assertTrue((a >= 50) && (a <= 100));
//		assertNotNull(main.mark1());
	}
}
