package com.main;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TestMark1.class, TestMark2.class, TestMark3.class, TestMark4.class, TestMark5.class, TestSum.class })
public class AllTests {

}
