package com.main;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestGender {

	@Test
	public void testGender() {
		Main main = new Main();
		String a=main.gender();
		assertTrue(a.equals("male")||(a.equals("female")));
//		assertNotNull(main.mark1());
	}
}
